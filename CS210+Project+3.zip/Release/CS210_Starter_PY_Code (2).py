import re
import string
import os

#This function will read a file of items sold and print a 
#list of all items sold and the amount of times each was sold.
def ProduceList():
    print('\nItems Sold:')
    #Open input file for reading using groceries object
    with open(r'U:\Project3\Release\CS210_Project_Three_Input_File.txt', 'r') as groceries:
    #Read file line by line and store values in list
        gList = groceries.read().splitlines()
    #Declare dictionary to hold all items sold and corresponding number sold
        gDict = {}
    #Add each item in groceries file to dictionary and keep track of number sold
        for item in gList:
            if item in gDict:
                gDict[item] += 1
            else:
                gDict[item] = 1 
    #Print dictionary of each item sold and how many were sold
        for item in gDict:
            print(item, end=' ')
            print(gDict[item])

            
        

#This function will read a file of items sold and return
#the number of times a given item (the parameter) was sold
def NumberSold(v):
    #Open input file for reading using groceries object
    with open(r'U:\Project3\Release\CS210_Project_Three_Input_File.txt', 'r') as groceries:
    #Read file line by line and store values in list
        gList = groceries.read().splitlines()
    #Declare dictionary to hold all items sold and corresponding number sold
        gDict = {}
    #Add each item in groceries file to dictionary and keep track of number sold
        for item in gList:
            if item in gDict:
                gDict[item] += 1
            else:
                gDict[item] = 1 
    #Return number of times user item appears in input file
    if v in gDict:
        return gDict[v]
    else:
        return 0


#This function will read a file and produce a histogram of
#all items sold along with a visual representation of how many
#times each was sold. This histogram will be written to a new file.
def ProduceHistogram():
    #Open input file for reading using groceries object
    with open(r'U:\Project3\Release\CS210_Project_Three_Input_File.txt', 'r') as groceries:
    #Read file line by line and store values in list
        gList = groceries.read().splitlines()
    #Declare dictionary to hold all items sold and corresponding number sold
        gDict = {}
    #Add each item in groceries file to dictionary and keep track of number sold
        for item in gList:
            if item in gDict:
                gDict[item] += 1
            else:
                gDict[item] = 1 
    #Open new frequency.dat file for writing histogram to
    with open('frequency.dat', 'w') as histogram:
        print('\nfrequency.dat file created')
    #Write each item to frequency.dat file
        for item in gDict:
            histogram.write(item)
    #Write number of asterisks that correspond to number sold after each item
            for i in range(gDict[item]):
                histogram.write('*')
            histogram.write('\n')
            



    
