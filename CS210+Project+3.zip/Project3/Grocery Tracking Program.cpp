/*
	This program will provide an interactive menu that allows users to choose whether they want to
	1. Produce a list of all items purchased in a given day along with the number of times each item was purchased.
	2. Produce a number representing how many times a specific item was purchased in a given day.
	3. Produce a text-based histogram listing all items purchased in a given day, along with a representation of the number of times each item was purchased.
	or 4. Exit the program
	
	Matthew Muller
	12/10/21
*/

#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <fstream>
#include <iostream>
using namespace std;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("CS210_Starter_PY_Code (2)");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"CS210_Starter_PY_Code (2)");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"CS210_Starter_PY_Code (2)");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}


int main()
{
//Declare and Define user menu input variable
	string menuChoice = " ";

//Display menu using while loop that exits if user chooses menu option 4
	while (menuChoice != "4") {
	//Display menu
		cout << "\n    Corner Grocer Item Tracking Program\n" << endl;
		cout << "1. Produce a list of all items sold today, including amount sold" << endl;
		cout << "2. Find out how many times a given item was sold today" << endl;
		cout << "3. Produce a text-based histogram listing all items purchased today, along with a representation of the number of times each item was purchased" << endl;
		cout << "4. Exit Program" << endl;
		cout << "Please enter 1, 2, 3, or 4" << endl;
	//Receive user menu choice
		cin >> menuChoice;
	//Validate user input
		while (menuChoice != "1" && menuChoice != "2" && menuChoice != "3" && menuChoice != "4") {
			cout << "Please enter 1, 2, 3, or 4" << endl;
			cin >> menuChoice;
		}
	//Perform desired action based on user menu choice
		if (menuChoice == "1") {
			CallProcedure("ProduceList");
		}
		else if (menuChoice == "2") {
			string item;
			cout << "What is the item?" << endl;
			cin >> item;
			cout << "\n" << callIntFunc("NumberSold", item) << " " << item << " sold" << endl;
		}
		else if (menuChoice == "3") {
			CallProcedure("ProduceHistogram");
		}
		else {
			cout << "Program Exited." << endl;
		}

	}

}